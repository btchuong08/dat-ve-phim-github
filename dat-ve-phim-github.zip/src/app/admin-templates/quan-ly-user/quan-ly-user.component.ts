import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quan-ly-user',
  templateUrl: './quan-ly-user.component.html',
  styleUrls: ['./quan-ly-user.component.scss']
})
export class QuanLyUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
