import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-templates',
  templateUrl: './admin-templates.component.html',
  styleUrls: ['./admin-templates.component.scss']
})
export class AdminTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
