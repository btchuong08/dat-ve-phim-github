import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-templates',
  templateUrl: './user-templates.component.html',
  styleUrls: ['./user-templates.component.scss']
})
export class UserTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
